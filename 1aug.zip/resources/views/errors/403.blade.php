@extends('layouts.app')

@section('content')
	<div class="container">
            <div class="content">
                <div class="text-danger">You are not authorised</div>
            </div>
        </div>

@endsection